Purpose
-----
rock-spock.c| The program is a modified game of rock paper scissors with two
    extra choices of rock and spock.
functions.c| The program is a geometry calculator that does various operations
    for different given fucntions. It does triangles, circles, rectangles, and
    regular polygons.
lab2.c| The program uses functions.c and makes it into a much nicer to use
    calculator by calling upon functions when asked.
ch5_pp8.c| Is a program that will the the user the closest aviable flight
    based upon a given 24 hour time.
ch5_pp11.c| Is a program that will print out a two digit number into its
    englished word form.
-----
Conclusion
-----

- I learned how to call upon functions contained in other files.

- Pair programming helped as during then I figured out how arrays work.
    good enough to apply them to the lab.

- I worked alone on the lab.

- I encountered one problem with a logic error in rock-spock.c where it
    was getting confusing lining up the 20ish different switch statements.
    To fix it I went to sleep and tried alligning it up the next day and
    it worked then.

- The calculator could not immediately end upon the user having its single
    operation completed.
   
-----